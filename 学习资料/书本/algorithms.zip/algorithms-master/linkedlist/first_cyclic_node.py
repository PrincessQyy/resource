# find the first node of a cycle in the linked list.

# 1 -> 2 -> 3 -> 4 -> 5 -> 1  => 1
# A -> B -> C -> D -> E -> C  => C

def firstCyclicNode():
    pass

