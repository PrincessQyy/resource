class Graph:
    def __init__(self, node, edges, source):
        pass
